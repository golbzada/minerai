// ==============================================================================
// MINERAÍ EXTENSÃO - BACKGROUND SERVICE WORKER (MANIFEST V3)
// ==============================================================================

const SUPABASE_URL = 'https://vqqzpkdxyaowqxdfshex.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_6uR1O7oSEjl_6Zyh_pHoUQ_uY5LnN7_';

const DASHBOARD_URLS = [
  'https://app.minerarads.com.br',
  'https://minerarads.com.br',
  'https://mineraiofertas.vercel.app',
  'http://localhost:5173'
];

// Obter usuário e sessão armazenados
async function getCurrentUser() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['minerai_user', 'minerai_session'], (result) => {
      resolve({
        user: result.minerai_user || null,
        session: result.minerai_session || null
      });
    });
  });
}

// Salvar dados do usuário e sessão na extensão
async function setStoredUser(user, session) {
  return new Promise((resolve) => {
    chrome.storage.local.set({
      minerai_user: user,
      minerai_session: session
    }, () => resolve());
  });
}

// Verificar status de autenticação (exige access_token válido)
async function checkAuthStatus() {
  const { user, session } = await getCurrentUser();
  if (user && session?.access_token) {
    return { authenticated: true, user };
  }

  // Tenta verificar se há sessão salva em cookies (localhost ou produção)
  try {
    for (const origin of DASHBOARD_URLS) {
      const cookies = await chrome.cookies.getAll({ url: origin });
      const authCookie = cookies.find(c => c.name.includes('supabase') || c.name.includes('auth') || c.name === 'minerai_user');
      if (authCookie) {
        try {
          const parsed = JSON.parse(decodeURIComponent(authCookie.value));
          if (parsed && (parsed.access_token || parsed.currentSession?.access_token)) {
            const token = parsed.access_token || parsed.currentSession?.access_token;
            const userData = parsed.user || parsed;
            const sessionData = { access_token: token };
            await setStoredUser(userData, sessionData);
            return { authenticated: true, user: userData };
          }
        } catch (e) {}
      }
    }
  } catch (e) {}

  return { authenticated: false };
}

// ==============================================================================
// METADADOS DA OFERTA
// Espelha src/utils/offerMeta.js: os campos que a tabela `offers` não tem
// (data de início, ID da biblioteca, ID da página) viajam num bloco JSON no
// final de `funnel_notes` e são escondidos na exibição do painel.
// ==============================================================================

const META_RE = /\s*\[\[minerai:(\{[\s\S]*?\})\]\]\s*/;

function decodeNotes(rawNotes) {
  const raw = typeof rawNotes === 'string' ? rawNotes : '';
  let meta = {};

  const match = raw.match(META_RE);
  if (match) {
    try {
      meta = JSON.parse(match[1]) || {};
    } catch (e) {
      meta = {};
    }
  }

  const notes = raw
    .replace(META_RE, '')
    .replace(/Dias rodando:\s*\d+\s*(?:\|\s*)?/i, '')
    .replace(/Capturado via Mineraí Extensão\.?\s*/i, '')
    .trim();

  return { notes, meta };
}

function encodeNotes(notes, meta) {
  const clean = decodeNotes(notes).notes;
  const payload = {};

  Object.keys(meta || {}).forEach((key) => {
    const value = meta[key];
    if (value !== null && value !== undefined && value !== '') {
      payload[key] = value;
    }
  });

  if (!Object.keys(payload).length) return clean;

  payload.v = 1;
  const block = `[[minerai:${JSON.stringify(payload)}]]`;
  return clean ? `${clean}\n\n${block}` : block;
}

function todayIso() {
  const d = new Date();
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().split('T')[0];
}

function historyEntry(date, count) {
  const n = Math.max(0, Number(count) || 0);
  // Grava nas duas nomenclaturas para o painel e os backups antigos lerem.
  return { date, count: n, ads_count: n, result_date: date, results_count: n };
}

function upsertHistory(history, date, count) {
  const byDate = new Map();

  (Array.isArray(history) ? history : []).forEach((item) => {
    if (!item || typeof item !== 'object') return;
    const raw = item.date || item.result_date;
    if (!raw) return;
    const key = String(raw).slice(0, 10);
    byDate.set(key, Number(item.count ?? item.ads_count ?? item.results_count ?? 0) || 0);
  });

  byDate.set(date, Math.max(0, Number(count) || 0));

  return Array.from(byDate.entries())
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([d, c]) => historyEntry(d, c));
}

// ==============================================================================
// PERSISTÊNCIA DA OFERTA CAPTURADA
// ==============================================================================

function supabaseHeaders(token, extra = {}) {
  return {
    'apikey': SUPABASE_ANON_KEY,
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...extra
  };
}

/** Aba padrão do usuário (a primeira criada). */
async function getDefaultTabId(userId, token) {
  try {
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/tabs?user_id=eq.${userId}&select=id&order=created_at.asc&limit=1`,
      { headers: supabaseHeaders(token) }
    );
    if (!res.ok) return null;
    const tabs = await res.json();
    return tabs?.[0]?.id || null;
  } catch (e) {
    return null;
  }
}

/**
 * Procura uma oferta já minerada do mesmo anunciante, para atualizar em vez de
 * criar duplicata. É o que faz o gráfico de evolução crescer sozinho a cada
 * nova mineração da mesma oferta.
 */
async function findExistingOffer(userId, token, offerData) {
  const base = `${SUPABASE_URL}/rest/v1/offers?user_id=eq.${userId}&select=id,name,ads_count,history,status,funnel_notes,landing_page,avatar_url,page_id&limit=1`;

  const queries = [];

  if (offerData.libraryId) {
    // Chave principal: o ID DESTE anúncio, guardado no bloco de metadados.
    // Assim, minerar dois anúncios diferentes da mesma página cria duas
    // ofertas em vez de um sobrescrever o outro.
    queries.push(`${base}&funnel_notes=like.*library_id%22:%22${encodeURIComponent(offerData.libraryId)}%22*`);
  } else if (offerData.pageId) {
    // Sem ID do anúncio, o anunciante é o melhor critério disponível.
    queries.push(`${base}&page_id=eq.${encodeURIComponent(offerData.pageId)}`);
  }

  for (const url of queries) {
    try {
      const res = await fetch(url, { headers: supabaseHeaders(token) });
      if (!res.ok) continue;
      const rows = await res.json();
      if (rows?.length) return rows[0];
    } catch (e) {}
  }

  return null;
}

function buildMeta(offerData, existing) {
  return {
    ...(existing ? decodeNotes(existing.funnel_notes).meta : {}),
    start_date: offerData.startDate || undefined,
    library_id: offerData.libraryId || undefined,
    page_id: offerData.pageId || undefined,
    page_url: offerData.pageUrl || undefined,
    ad_url: offerData.adUrl || undefined,
    page_ads_url: offerData.pageAdsUrl || undefined,
    source: 'extension',
    captured_at: new Date().toISOString()
  };
}

/**
 * Oferta já existe: registra a medição de hoje e atualiza os campos que a Meta
 * pode ter mudado, preservando o que o usuário editou à mão no painel.
 */
async function updateExistingOffer(existing, offerData, token) {
  const today = todayIso();
  const adsCount = Math.max(0, parseInt(offerData.adsCount, 10) || 1);
  const userNotes = decodeNotes(existing.funnel_notes).notes;

  const patch = {
    ads_count: adsCount,
    history: upsertHistory(existing.history, today, adsCount),
    funnel_notes: encodeNotes(userNotes, buildMeta(offerData, existing)),
    updated_at: new Date().toISOString()
  };

  if (offerData.landingPage) patch.landing_page = offerData.landingPage;
  if (offerData.libraryUrl) patch.library_url = offerData.libraryUrl;
  if (offerData.avatarUrl && !existing.avatar_url) patch.avatar_url = offerData.avatarUrl;
  if (offerData.pageId && !existing.page_id) patch.page_id = String(offerData.pageId);

  // Nome só é corrigido quando o que está salvo é o placeholder genérico.
  if (offerData.name && /^oferta minerada$/i.test(existing.name || '')) {
    patch.name = offerData.name;
  }

  // O estágio vem do tempo de veiculação, que só cresce — então é seguro
  // reescrever. A exceção é a oferta cujo estágio o usuário fixou no painel.
  if (!decodeNotes(existing.funnel_notes).meta.status_manual) {
    patch.status = offerData.status || 'testing';
  }

  const res = await fetch(`${SUPABASE_URL}/rest/v1/offers?id=eq.${existing.id}`, {
    method: 'PATCH',
    headers: supabaseHeaders(token, { 'Prefer': 'return=representation' }),
    body: JSON.stringify(patch)
  });

  if (!res.ok) {
    const errorText = await res.text();
    console.error('Erro ao atualizar oferta no Supabase:', errorText);
    if (res.status === 401 || res.status === 403) {
      throw new Error('Sessão expirada. Faça login novamente no Mineraí.');
    }
    throw new Error('Falha ao atualizar a oferta no banco de dados Mineraí.');
  }

  const saved = await res.json();
  return saved?.[0] || patch;
}

async function saveCapturedOffer(offerData) {
  const { user, session } = await getCurrentUser();
  if (!user || !session?.access_token) {
    throw new Error('Você precisa estar conectado no Mineraí para salvar ofertas.');
  }

  const userId = user.id;
  const token = session.access_token;
  const today = todayIso();

  const adsCount = Math.max(0, parseInt(offerData.adsCount, 10) || 1);
  const existing = await findExistingOffer(userId, token, offerData);

  if (existing) {
    const offer = await updateExistingOffer(existing, offerData, token);
    return { success: true, updated: true, offer };
  }

  // ---------------------------------------------------------------------------
  // Oferta nova
  // ---------------------------------------------------------------------------
  const meta = buildMeta(offerData, null);
  const tabId = await getDefaultTabId(userId, token);

  const payload = {
    user_id: userId,
    tab_id: tabId,
    name: offerData.name || 'Oferta Minerada',
    // ID da PÁGINA do anunciante (antes era gravado o ID do anúncio aqui, o que
    // quebrava o avatar e a identificação da oferta no painel).
    page_id: String(offerData.pageId || ''),
    ads_count: adsCount,
    library_url: offerData.libraryUrl || '',
    landing_page: offerData.landingPage || '',
    affiliate_link: '',
    funnel_notes: encodeNotes(offerData.notes || '', meta),
    status: offerData.status || 'testing',
    niche: offerData.niche || 'Outros',
    avatar_url: offerData.avatarUrl || null,
    history: [historyEntry(today, adsCount)],
    updated_at: new Date().toISOString()
  };

  const insertRes = await fetch(`${SUPABASE_URL}/rest/v1/offers`, {
    method: 'POST',
    headers: supabaseHeaders(token, { 'Prefer': 'return=representation' }),
    body: JSON.stringify(payload)
  });

  if (!insertRes.ok) {
    const errorText = await insertRes.text();
    console.error('Erro ao inserir oferta no Supabase:', errorText);
    if (insertRes.status === 401 || insertRes.status === 403) {
      throw new Error('Sessão expirada. Faça login novamente no Mineraí.');
    }
    throw new Error('Falha ao salvar no banco de dados Mineraí.');
  }

  const saved = await insertRes.json();
  return { success: true, updated: false, offer: saved?.[0] || payload };
}

/**
 * Sincronização em lote: percorre os cards visíveis e registra a medição de
 * hoje apenas nas ofertas que JÁ estão no painel. Não cria ofertas novas —
 * é o que mantém o gráfico de evolução crescendo sem cadastro manual.
 */
async function syncCapturedOffers(offers) {
  const { user, session } = await getCurrentUser();
  if (!user || !session?.access_token) {
    throw new Error('Você precisa estar conectado no Mineraí para sincronizar.');
  }

  const userId = user.id;
  const token = session.access_token;

  let updated = 0;
  let skipped = 0;
  const failures = [];

  for (const offerData of offers || []) {
    try {
      const existing = await findExistingOffer(userId, token, offerData);
      if (!existing) {
        skipped += 1;
        continue;
      }
      await updateExistingOffer(existing, offerData, token);
      updated += 1;
    } catch (err) {
      failures.push(err.message);
    }
  }

  return { success: true, updated, skipped, failures };
}

// Ouvir mensagens dos content scripts e popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'CHECK_AUTH') {
    checkAuthStatus().then(sendResponse);
    return true;
  }

  if (message.type === 'SET_AUTH_USER') {
    setStoredUser(message.user, message.session).then(() => {
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === 'SAVE_OFFER') {
    saveCapturedOffer(message.offer)
      .then(res => sendResponse({ success: true, data: res }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }

  if (message.type === 'SYNC_OFFERS') {
    syncCapturedOffers(message.offers)
      .then(res => sendResponse({ success: true, data: res }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }

  if (message.type === 'OPEN_DASHBOARD') {
    chrome.tabs.create({ url: message.url || DASHBOARD_URLS[0] });
    sendResponse({ success: true });
    return true;
  }

  if (message.type === 'DOWNLOAD_MEDIA') {
    if (chrome.downloads && chrome.downloads.download) {
      chrome.downloads.download({
        url: message.url,
        filename: message.filename || `anuncio_${Date.now()}.${message.url?.includes('.mp4') ? 'mp4' : 'jpg'}`,
        saveAs: false
      }, (downloadId) => {
        if (chrome.runtime?.lastError) {
          sendResponse({ success: false, error: chrome.runtime.lastError.message });
        } else {
          sendResponse({ success: true, downloadId });
        }
      });
    } else {
      sendResponse({ success: false, error: 'API de download não disponível' });
    }
    return true;
  }
});
